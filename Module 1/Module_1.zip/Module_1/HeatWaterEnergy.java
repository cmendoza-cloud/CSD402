// Carmen Mendoza
// Heat Water Energy

// Program to calculate the energy required to heat water
import java.util.Scanner;

public class HeatWaterEnergy {

    // Method to calculate energy
    public static double calculateEnergy(double waterMass, double initialTemp, double finalTemp) {
        // Formula: Q = waterMass * (finalTemperature - initialTemperature) * 4184
        return waterMass * (finalTemp - initialTemp) * 4184;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            // Get input from the user
            System.out.print("Enter the amount of water in kilograms: ");
            double waterMass = scanner.nextDouble();

            System.out.print("Enter the initial temperature in Celsius: ");
            double initialTemp = scanner.nextDouble();

            System.out.print("Enter the final temperature in Celsius: ");
            double finalTemp = scanner.nextDouble();

            // Calculate the energy
            double energy = calculateEnergy(waterMass, initialTemp, finalTemp);

            // Display the result
            System.out.printf("The energy needed to heat the water is %.2f Joules.%n", energy);
        } catch (Exception e) {
            System.out.println("Please enter valid numerical values.");
        } finally {
            scanner.close();
        }
    }
}
