import java.util.Random;
import java.util.Scanner;

public class RockPaperScissors {

    // Function to convert the choice number into a string
    public static String choiceToString(int choice) {
        if (choice == 1) {
            return "Rock";
        } else if (choice == 2) {
            return "Paper";
        } else if (choice == 3) {
            return "Scissors";
        }
        return "";
    }

    // Function to determine the winner
    public static String determineWinner(int userChoice, int computerChoice) {
        if (userChoice == computerChoice) {
            return "It's a tie!";
        } else if ((userChoice == 1 && computerChoice == 3) || 
                   (userChoice == 2 && computerChoice == 1) || 
                   (userChoice == 3 && computerChoice == 2)) {
            return "You win!";
        } else {
            return "You lose!";
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.println("Welcome to Rock-Paper-Scissors!");

            // Computer's choice is randomly generated (1=Rock, 2=Paper, 3=Scissors)
            Random random = new Random();
            int computerChoice = random.nextInt(3) + 1;

            // User's choice input
            System.out.print("Enter your choice (1=Rock, 2=Paper, 3=Scissors): ");
            int userChoice = scanner.nextInt();

            if (userChoice < 1 || userChoice > 3) {
                System.out.println("Invalid choice. Please enter 1, 2, or 3.");
                return;
            }

            // Display the choices
            System.out.println("\nComputer chose: " + choiceToString(computerChoice));
            System.out.println("You chose: " + choiceToString(userChoice));

            // Determine the result and display it
            String result = determineWinner(userChoice, computerChoice);
            System.out.println(result);

        } catch (Exception e) {
            System.out.println("Invalid input. Please enter a number (1, 2, or 3).");
        } finally {
            scanner.close(); // Ensure the scanner is closed in the finally block
        }
    }
}
