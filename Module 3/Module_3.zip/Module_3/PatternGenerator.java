public class PatternGenerator {
    public static void main(String[] args) {
        // Loop to print each row of the pattern
        for (int i = 0; i < 7; i++) {
            // Print leading spaces for alignment
            for (int j = 0; j < 6 - i; j++) {
                System.out.print(" ");
            }
            
            // Print the numbers in increasing order
            int num = 1;
            for (int j = 0; j <= i; j++) {
                System.out.print(num + " ");
                num *= 2; // Double the number
            }
            
            // Print the numbers in decreasing order
            num /= 2; // Adjust to the last printed value
            for (int j = 0; j < i; j++) {
                num /= 2; // Half the number
                System.out.print(num + " ");
            }
            
            // Print the "@" symbol at the end of each line
            System.out.println(" @");
        }
    }
}

